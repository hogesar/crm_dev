<?php
require "goutte-v1.0.7.phar";

use Goutte\Client;
/*
	call http://my.server.com/path/to/me/index.php?id=51288146"

*/

fetch($_GET["id"]);

	function fetch($id) {
		$client = new Client();
		if (!$id) {
			$id = "51288142";
		}
		$url = 'http://www.rightmove.co.uk/property-for-sale/property-' . $id . '.html?showcase=false';
		$crawler = $client->request('GET', $url);

		$aPropData = array();

		$domCSSPath = 'div.property-header-bedroom-and-price > div > h1'; 
		$aPropData["title"] = $crawler->filter($domCSSPath)->each(function ($node) {
			return trim($node->text());
		});

		$domCSSPath = 'div.property-header-bedroom-and-price > div > address'; 
		$aPropData["address"] = $crawler->filter($domCSSPath)->each(function ($node) {
			return trim($node->text());
		});
		
		$domCSSPath = '#propertyHeaderPrice > small'; 
		$aPropData["status"] = $crawler->filter($domCSSPath)->each(function ($node) {
			return trim($node->text());
		});

		$domCSSPath = '#propertyHeaderPrice > strong'; 
		$aPropData["price"] = $crawler->filter($domCSSPath)->each(function ($node) {
			return trim($node->text());
		});
	
		$aDetails = array(); 
		$domCSSPath = 'div.sect.key-features > ul > li';
		$aPropData["details"] = $crawler->filter($domCSSPath)->each(function ($node) {
			return trim($node->text());	
		});

		$aPropData = optimize($aPropData);
		
		//images;
		$domXPath = '//*[contains(@id,"thumbnail")]/img';
		$aPropData["thumbs"] = $crawler->filterXPath($domXPath)->each(function ($node) {
			return trim($node->attr("src"));
		});

		$domXPath = 'noscript > div > ul > li > a > img';
		$aPropData["images"] = $crawler->filter($domXPath)->each(function ($node) {
			return trim($node->attr("src"));
		});

		$domXPath = '#floorplanTabs > noscript > img';
		$aPropData["floorplans"] = $crawler->filter($domXPath)->each(function ($node) {
			return trim($node->attr("src"));
		});


		echo json_encode($aPropData,JSON_UNESCAPED_UNICODE);
	}

	function optimize($config) {
	    foreach ($config as $key => $value) {
	        if  (is_array($value) && (count($value) == 1) && isset($value[0]) ) {
		    $config[$key] = $value[0];              
		}
	    }
	    return $config;
	}

